package com.mooc.house.api.model;

public class Agency {
 
  private Integer id;
  private String  name;
  private String  address;
  private String  phone;
  private String  email;
  private String  aboutUs;
  private String  webSite;
  private String  mobile;
  
  public Integer getId() {
    return id;
  }
  public void setId(Integer id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getPhone() {
    return phone;
  }
  public void setPhone(String phone) {
    this.phone = phone;
  }
  public String getEmail() {
    return email;
  }
  public void setEmail(String email) {
    this.email = email;
  }
  public String getAboutUs() {
    return aboutUs;
  }
  public void setAboutUs(String aboutUs) {
    this.aboutUs = aboutUs;
  }
  public String getWebSite() {
    return webSite;
  }
  public void setWebSite(String webSite) {
    this.webSite = webSite;
  }
  public String getMobile() {
    return mobile;
  }
  public void setMobile(String mobile) {
    this.mobile = mobile;
  }
  
  

}
