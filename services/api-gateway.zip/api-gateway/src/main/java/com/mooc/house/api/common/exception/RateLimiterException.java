package com.mooc.house.api.common.exception;

public class RateLimiterException extends RuntimeException{

 
  private static final long serialVersionUID = 1L;
  
  

}
